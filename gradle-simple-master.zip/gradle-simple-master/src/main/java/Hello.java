
public class Hello {
  
  public static String GREETING = "Hello world!";
  
  public static void main(String []args) {
    
  }  
}

